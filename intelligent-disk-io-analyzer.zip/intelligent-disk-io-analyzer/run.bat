@echo off
if not exist disk_analyzer.exe call build.bat
if not exist disk_analyzer.exe exit /b 1
disk_analyzer.exe 8080
pause
