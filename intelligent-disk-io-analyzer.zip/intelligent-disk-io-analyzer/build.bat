@echo off
where gcc >nul 2>nul
if errorlevel 1 (
  echo GCC was not found. Install MinGW-w64 and add its bin folder to PATH.
  pause
  exit /b 1
)
gcc -std=c11 -O2 -Wall -Wextra -o disk_analyzer.exe src\server.c -lws2_32
if errorlevel 1 (
  echo Build failed. Check the compiler messages above.
  pause
  exit /b 1
)
echo Build successful: disk_analyzer.exe
